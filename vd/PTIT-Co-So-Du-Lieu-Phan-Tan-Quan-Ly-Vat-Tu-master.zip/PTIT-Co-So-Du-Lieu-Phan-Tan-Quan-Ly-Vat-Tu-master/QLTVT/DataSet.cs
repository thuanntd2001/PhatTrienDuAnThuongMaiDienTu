﻿namespace QLTVT
{


    partial class DataSet
    {
    }
}

namespace QLTVT.DataSetTableAdapters {
    
    
    public partial class NhanVienTableAdapter {
    }
}

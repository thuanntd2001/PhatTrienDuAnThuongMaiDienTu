﻿using DevExpress.XtraReports.UI;
using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;

namespace QLTVT.ReportForm
{
    public partial class ReportDanhSachVatTu : DevExpress.XtraReports.UI.XtraReport
    {
        public ReportDanhSachVatTu()
        {
            InitializeComponent();
        }

    }
}
